"use strict";
var Abschluss;
(function (Abschluss) {
    class Person {
        constructor() {
            this.posX = 0;
            this.posY = 0;
        }
    }
    Abschluss.Person = Person;
})(Abschluss || (Abschluss = {}));
//# sourceMappingURL=Person.js.map