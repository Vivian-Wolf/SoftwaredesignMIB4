"use strict";
function tosy1() {
    let userInput = document.getElementById("userInput").value;
    document.getElementById("mainInfo").innerHTML = "You wrote: " + userInput;
    console.log(userInput);
}
//# sourceMappingURL=main.js.map