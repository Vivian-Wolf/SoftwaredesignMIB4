namespace Abschluss {
    export class Person {
        public name: String;
        public lifepoints: number;
        canBeAttacked: boolean;
        posX: number = 0;
        posY: number = 0;
    }
}